ESTRIBO — assets PNG para integração imediata

Arquivos:
- logo-estribo-horizontal.png
- logo-estribo-horizontal-white.png
- simbolo-estribo.png
- favicon-32.png
- apple-touch-icon.png
- app-icon-512.png

Destino recomendado:
static/site_publico/brand/

IMPORTANTE:
A integração atual foi preparada para arquivos .svg. Para usar este pacote agora,
troque as referências em base_public.html/header/footer de .svg para .png.

Exemplo:
logo-estribo-horizontal.svg -> logo-estribo-horizontal.png
logo-estribo-horizontal-white.svg -> logo-estribo-horizontal-white.png
favicon.svg -> favicon-32.png (ou mantenha somente o PNG por enquanto)

Esses PNGs foram preparados a partir do logo aprovado nesta conversa e resolvem
o problema do asset quebrado imediatamente.

Recomendação futura:
vetorizar o logo profissionalmente e substituir os PNGs pelos SVGs finais,
mantendo exatamente os mesmos caminhos/nomes previstos na arquitetura.
